import Navbar from '@/components/Navbar/Nav';
import React from 'react';

const page = () => {
  return (
    <div>
      {/* <div className='h-[300px] top-28 left-28 w-[300px] relative bg-black
       before:absolute before:w-full before:h-full
        before:top-0 before:left-16 before:bg-black before:-skew-x-12'>
          
        </div> */}
    </div>
  );
};

export default page;